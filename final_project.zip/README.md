# Crypto Exchange

Jednoduchá demo aplikace pro správu kryptoměnových peněženek a obchodování, vytvořená v Django.

## Funkce
- Registrace a přihlášení uživatelů
- Přidání peněženek a správa zůstatků
- Vklady a výběry (deposit/withdraw)
- Nákup a prodej kryptoměn (BUY/SELL)
- Historie obchodů přístupná uživateli
- Administrace přes Django Admin
- PostgreSQL databáze